globalThis.plugin = { tools: { echo: function(args) { return args; } } };
